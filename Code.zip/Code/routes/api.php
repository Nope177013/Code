<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StatisticsController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AccessTokenController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('auth')->middleware(['api-authentication', 'throttle:10,1'])->group(function () {
    Route::post('token', [AccessTokenController::class, 'issueToken']);
});

Route::middleware('auth:api')->group(function () {
    Route::get('user/roster', [UserController::class, 'roster']);
    Route::post('user/roster', [UserController::class, 'updateRoster']);
    Route::apiResource('user', UserController::class);

    Route::apiResource('statistics', StatisticsController::class);
});

Route::get('ping', fn () => response()->noContent(200));
