<?php

namespace Database\Seeders;

use App\Models\Project;
use Illuminate\Database\Seeder;

class AddDummySprintSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Project::create([
            'name'          => 'Scrum Dashboard',
            'sprints'       => 4,
            'sprint_length' => 14,
            'starts_at'     => new \DateTime()
        ]);
    }
}
