<?php

namespace Database\Seeders;

use App\Models\User;
use Faker\Factory;
use Illuminate\Database\Seeder;

class DummyUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Factory::create();

        // Create dummy user
        $user = new User();
        $user->name = 'Test Gebruiker';
        $user->email = 'test.user@student.hu.nl';
        $user->password = bcrypt('test');
        $user->save();

        // Add roster to the user that we've just created
        $user->roster()->create([
            'mondays'    => $faker->boolean,
            'tuesdays'   => $faker->boolean,
            'wednesdays' => $faker->boolean,
            'thursdays'  => $faker->boolean,
            'fridays'    => $faker->boolean,
            'saturdays'  => $faker->boolean,
            'sundays'    => $faker->boolean,
        ]);
    }
}
