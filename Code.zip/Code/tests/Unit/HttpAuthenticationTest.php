<?php

namespace Tests\Unit;

use App\Models\User;
use Laravel\Passport\Passport;
use Tests\TestCase;

class HttpAuthenticationTest extends TestCase
{
    /**
     * Validate the status of a guest-accessible route
     */
    public function testGuestRoute()
    {
        // Arrange

        // Act
        $response = $this->get(url('api/ping'));

        // Assert
        $response->assertStatus(200);
    }

    /**
     * Validate the status of an authenticated route (without Bearer token)
     */
    public function testAuthenticatedRouteWithoutToken()
    {
        // Arrange

        // Act
        $response = $this->get(url('api/statistics'));

        // Assert
        $response->assertStatus(500);
    }

    /**
     * Validate the status of an authenticated route (with Bearer token)
     */
    public function testAuthenticatedRouteWithToken()
    {
        // Arrange
        $user = User::factory()->create();

        // Act
        Passport::actingAs($user);
        $response = $this->get('api/statistics');

        // Assert
        $response->assertStatus(200);
    }

    /**
     * Validate the format of the user resource route
     */
    public function testUserResourceFormat()
    {
        // Arrange
        $user = User::factory()->create();

        // Act
        Passport::actingAs($user);
        $response = $this->getJson('api/user');

        // Assert
        $response->assertStatus(200)
                 ->assertJsonPath('data.email', $user->email);
    }
}
