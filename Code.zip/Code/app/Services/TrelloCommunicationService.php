<?php

namespace App\Services;

use App\Constants\TrelloApiEndpoints as TrelloAPI;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Client\Response;

/**
 * Class TrelloCommunicationService
 * @package App\Services
 */
class TrelloCommunicationService
{
    /** @var string Active board */
    protected string $board;

    /** @var string Trello API key */
    private string $key;

    /** @var string Trello API integration token */
    private string $token;

    /**
     * TrelloCommunicationService constructor.
     * @param string $board
     * @param string|null $key
     * @param string|null $token
     */
    public function __construct(string $board, ?string $key = null, ?string $token = null)
    {
        $this->board = $board;
        $this->key   = $key ?: env('TRELLO_KEY');
        $this->token = $token ?: env('TRELLO_TOKEN');
    }

    public function getPluginData($id)
    {
        $response = $this->apiGet(TrelloAPI::GET_PLUGIN_DATA, $id)->json();
        return $response;
    }

    /**
     * Returns a collection of board members
     * @return Collection
     */
    public function getBoardMembers() : Collection
    {
        $response = $this->apiGet(TrelloAPI::GET_BOARD_MEMBERS)->json();

        return collect($response)->filter(function ($user) {
            // Remove 'scrumdash_api' bot from the results
            return $user['id'] !== '608ff9a555f50d693d82a23f';
        })->map(function ($user) {
            return [
                'id' => $user['id'],
                'username' => $user['username'],
                'name' => $user['fullName'],
            ];
        });
    }

    /**
     * @return Collection
     */
    public function getBoardMembersId() : Collection
    {
        $response = $this->apiGet(TrelloAPI::GET_BOARD_MEMBERS)->json();

        return collect($response)->filter(function ($user) {
            // Remove 'scrumdash_api' bot from the results
            return $user['id'] !== '608ff9a555f50d693d82a23f';
        })->map(function ($user) {
            return [
                'id' => $user['id'],
            ];
        });
    }

    /**
     * Returns a collection of lists from the board
     * @param false $with_closed
     * @return Collection
     */
    public function getBoardLists(bool $with_closed = false) : Collection
    {
        $response = $this->apiGet(TrelloAPI::GET_BOARD_LISTS)->json();

        return collect($response)->filter(function ($list) use ($with_closed) {
            return $with_closed || $list['closed'] === false;
        })->map(function ($list) {
            return [
                'id' => $list['id'],
                'name' => $list['name'],
            ];
        });
    }

    /**
     * Returns the collection of cards from a list
     * @param string $list_id
     * @return Collection
     */
    public function getListCards(string $list_id)
    {
        $response = $this->apiGet(TrelloAPI::GET_LIST_CARDS, $list_id)->json();

        return collect($response);
    }

    /**
     * Creates a GET request to the Trello API (with credentials)
     * @param string $endpoint
     * @param string|null $identifier_value
     * @return Response
     */
    private function apiGet(string $endpoint, ?string $identifier_value = null) : Response
    {
        if ($identifier_value === null) {
            $identifier_value = $this->board;
        }

        $url = $this->endpointFormatter($endpoint, $identifier_value);

        return Http::get($url, [
            'key' => $this->key,
            'token' => $this->token
        ]);
    }

    /**
     * Formats the endpoint URL
     * @param string $endpoint
     * @param string $identifier_value
     * @return array|string|string[]
     */
    private function endpointFormatter(string $endpoint, string $identifier_value) : string
    {
        $suffix = str_replace('{id}', $identifier_value, $endpoint);

        return join('', ['https://api.trello.com', $suffix]);
    }
}
