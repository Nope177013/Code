<?php

namespace App\Services;

use App\Models\Project;
use Illuminate\Support\Collection;
use Exception;

/**
 * Class FilterService
 * @package App\Services
 */
class FilterService
{
    /**
     * Filter cards (from a list) for the current sprint
     * @param Project $project
     * @param string $board_id
     * @param string $list_id
     * @param string $label_format
     * @return Collection
     * @throws Exception
     */
    public function withinSprint(
        Project $project,
        string $board_id,
        string $list_id,
        string $label_format = 'sprint %d'
    ) : Collection {
        if (! $board_id || ! $list_id) {
            throw new Exception('One or more required parameters are missing!');
        }

        // Declare variables and initiate service
        $startDate = new \DateTime($project->starts_at);
        $currentDate = new \DateTime();
        $sprintLength = $project->sprint_length;
        $trelloService = new TrelloCommunicationService($board_id);

        // Calculate active sprint
        $difference = $currentDate->diff($startDate)->format('%a');
        $floored = floor($difference / $sprintLength);

        // If the active sprint number is above the 'sprints' threshold, just return the latest possible sprint
        $currentSprint = $floored > ($project->sprints - 1) ? ($project->sprints - 1)
                                                            : $floored;

        $sprintLabel = sprintf($label_format, $currentSprint);

        // Retrieve cards from $list_id
        $cards = $trelloService->getListCards($list_id);

        return $cards->filter(function($card) use ($sprintLabel) {
            return $card['labels'] &&
                   $card['labels'][0] &&
                   $card['labels'][0]['name'] === $sprintLabel;
        });
    }
}
