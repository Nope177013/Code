<?php

namespace App\Constants;

/**
 * Class TrelloApiEndpoints
 * @package App\Constants
 */
class TrelloApiEndpoints
{
    const GET_BOARD_MEMBERS = '/1/boards/{id}/members';
    const GET_BOARD_LISTS   = '/1/boards/{id}/lists';
    const GET_LIST_CARDS    = '/1/lists/{id}/cards';
    const GET_PLUGIN_DATA   = '/1/cards/{id}/pluginData';
}
