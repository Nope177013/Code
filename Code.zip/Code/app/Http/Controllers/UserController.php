<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserRosterRequest;
use App\Http\Resources\UserResource;
use App\Http\Resources\UserRosterResource;
use App\Models\UserRoster;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return UserResource
     */
    public function index() : UserResource
    {
        return new UserResource(auth()->user());
    }

    /**
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function roster() : \Illuminate\Http\Resources\Json\AnonymousResourceCollection
    {
        $rosters = auth()->user()->rosters()->select(
            'user_rosters.*',
            'projects.name as project_name',
            'projects.sprints as project_sprints',
        )->join('projects', 'projects.id', 'user_rosters.project_id')
         ->get();

        return UserRosterResource::collection($rosters);
    }

    /**
     * @param UserRosterRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateRoster(UserRosterRequest $request) : JsonResponse
    {
        $projects = collect($request->get('projects'));
        $projects->each(function ($data, $project) {
            collect($data)->each(function ($sprint, $index) use ($project) {
                UserRoster::whereHas('project', function ($query) use ($project) {
                    return $query->where('name', $project);
                })->where('sprint', '=', $index)
                  ->where('user_id', '=', auth()->user()->id)
                  ->update($sprint['calendar']);
            });
        });

        return response()->json([]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
