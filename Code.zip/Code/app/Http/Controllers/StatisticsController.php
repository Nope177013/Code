<?php

namespace App\Http\Controllers;

use App\Http\Resources\BurndownChartResource;
use App\Http\Resources\StatisticsResource;
use App\Http\Resources\DateResource;
use App\Models\Project;
use App\Services\FilterService;
use App\Services\TrelloCommunicationService;
use DateTime;
use DatePeriod;
use DateInterval;

class StatisticsController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return StatisticsResource
     */
    public function index() : StatisticsResource
    {
        /**
         * TODO when creating the burn down chart: To the data(cards), apply the filter given below, so that the data
         *      is relevant to the active sprint. Oh and when adding new (data) filters (e.x. for the burn down chart),
         *      be sure to create those in the new 'FilterService.php' (App\Services\FilterService), not in here.
         *
         * $filter = new FilterService();
         * $project = Project::where('name', 'Test Project')->first();
         * $filtered = $filter->withinSprint($project, 'sXOShG1C', '607d5adfe533f33c3886743a');
         *
         */
        $data = $this->calculateStatisticsBatch();

        return new StatisticsResource($data);
    }

    /**
     * Calculate statistics batch
     * @param Project $project
     * @return array
     */
    private function calculateStatisticsBatch() : array
    {
        // Board id's
        $board = [
            'Scrum Dashboard' => 'sXOShG1C',
            'Pet Track&Care'  => '9gqItbXR',
            'OV App'          => 'lNNFWnww'
        ];

        // Count all team members their ID, API account excluded
        $allBoardMembersId = function($board){
            return (new TrelloCommunicationService($board))->getBoardMembersId();
        };

        // Count all tickets which are done
        $allCompletedTickets = function($board, $card){
            return (new TrelloCommunicationService($board))->getListCards($card)->count();
        };

        // Count all tickets which are active
        $allActiveTickets = function($board, $card){
            return (new TrelloCommunicationService($board))->getListCards($card)->count();
        };

        // Count all open tickets
        $allOpenTickets = function($board, $card){
            return (new TrelloCommunicationService($board))->getListCards($card)->count();
        };

        // Get all user IDs and cast the given Collections to Arrays
        $teamMembersSD = $allBoardMembersId($board["Scrum Dashboard"])->toArray();
        $teamMembersPT = $allBoardMembersId($board["Pet Track&Care"])->toArray();
        $teamMembersOV = $allBoardMembersId($board["OV App"])->toArray();

        $teamMembers = array_merge($teamMembersSD, $teamMembersPT, $teamMembersOV);

        // Count the 'Done' cards
        $ticketsDone = [
            $allCompletedTickets($board["Scrum Dashboard"], '607d5ae29da56a6e47af0e56'),
            $allCompletedTickets($board["Pet Track&Care"], '601cfda46a9e8d6bc9a8ffa8'),
            $allCompletedTickets($board["OV App"], '5fad0aaa60aee06a30a15fe4')
        ];

        // Count the 'Active' cards
        $ticketsActive = [
            $allActiveTickets($board["Scrum Dashboard"], '607d5adfe533f33c3886743a'),
            $allActiveTickets($board["Pet Track&Care"], '601cfd9f56e35d4d9a801a39'),
            $allActiveTickets($board["OV App"], '5fad0aa512c9fb759716690e')
        ];

        // Count the 'Open' cards
        $ticketsOpen = [
            $allOpenTickets($board["Scrum Dashboard"],'607d5add06ab2f63c267eefb'),
            $allCompletedTickets($board["Pet Track&Care"], '601cfd9eea0aa78f7670f375' ),
            $allOpenTickets($board["OV App"], '5fad0aa4392dfa09200ce27c')
        ];

        $getData = function($id)
        {
            $idArray = array();
            $dates = array();
            $connection = new TrelloCommunicationService('sXOShG1C');

            array_push($idArray, $connection->getListCards($id));

            for($i = 0; $i < count($idArray[0]); $i++)
            {
                array_push($dates, $idArray[0][$i]);
            }

            $moredates = array();
            $ids = array();

            $dateValues[0] = array();
            unset($dateValues[0]);

            for($i = 0; $i < count($dates); $i++)
            {
                if(array_key_exists(0, $dates[$i]["labels"]))
                {
                    if($dates[$i]["labels"][0]["name"] == "sprint 4")
                    {
                        $variableDate = $dates[$i]["dateLastActivity"];
                        array_push($moredates, substr($variableDate, 0, strpos($variableDate, 'T')));

                        $variableId = $dates[$i]["id"];
                        array_push($ids, $connection->getPluginData($variableId)[0]["value"]);

                        $date = substr($variableDate, 0, strpos($variableDate, 'T'));
                        $replaceString = str_replace('{"estimate":"', "", $connection->getPluginData($variableId)[0]["value"]);
                        $removePartString = substr($replaceString, 0, strpos($replaceString, '"'));
                        
                        if(array_key_exists($date, $dateValues))
                        {    
                            array_push($dateValues[$date], $removePartString); 
                        }
                        else
                        {
                            $dateValues[$date] = array();
                            array_push($dateValues[$date], $removePartString);
                        } 
                    }
                }
            }

            $numbers = array();

            for($i = 0; $i < count($ids); $i++)
            {
                $replaceString = str_replace('{"estimate":"', "", $ids[$i]);
                $removePartString = substr($replaceString, 0, strpos($replaceString, '"'));

                array_push($numbers, $removePartString);
            }

            return [$moredates, array_sum($numbers), $dateValues];
        };

        $getDatesFromRange = function($start, $end, $format = 'Y-m-d') 
        {
            $array = array();
            
            $interval = new DateInterval('P1D');
          
            $realEnd = new DateTime($end);
            $realEnd->add($interval);
          
            $period = new DatePeriod(new DateTime($start), $interval, $realEnd);
          
            foreach($period as $date) 
            {                 
                $array[] = $date->format($format); 
            }
          
            return $array;
        };
          
        $getDone = $getData('607d5ae29da56a6e47af0e56')[1];
        $getTesting = $getData('607d5ad58db8863fd87cb0d3')[1];
        $getDoing = $getData('607d5add06ab2f63c267eefb')[1];
        $getSBacklog = $getData('607d5adfe533f33c3886743a')[1];
        $getPBacklog = $getData('607d5ae1d01d570a1da92ef4')[1];

        $getDatesAndValues = $getData('607d5ae29da56a6e47af0e56')[2];
        $sumDatesAndValues = array();

        foreach($getDatesAndValues as $x => $x_value)
        {
            array_push($sumDatesAndValues, array_sum($x_value));
        }

        $allTickets = array($getDone, $getTesting, $getDoing, $getSBacklog, $getPBacklog);

        $idealBurndownLine = function($total_tickets)
        {
            $idealBurndown = [];
            $divide = $total_tickets / 10;
            $dates = ['Monday', 'Thuesday', 'Wednesday', 'Thursday', 'Friday', 'Saterday', 'Sunday',
            'Monday', 'Thuesday', 'Wednesday', 'Thursday', 'Friday', 'Saterday', 'Sunday'];


            for($i = 0; $i < 14; $i++)
            {
                array_push($idealBurndown, $total_tickets);

                if($dates[$i] == 'Saterday' || $dates[$i] == 'Sunday')
                {
                    $total_tickets;
                }
                else
                {
                    $total_tickets = round($total_tickets = $total_tickets - $divide, 2);
                }     
            }

            return $idealBurndown;
        };

        $completedTasks = array();
        $arraysum = array_sum($allTickets);
        $remainingTasks = array();

        $project = function(Project $project)
        {
            $startDate = new \DateTime($project->starts_at);
            $currentDate = new \DateTime();
            $sprintLength = $project->sprint_length;

            $difference = $currentDate->diff($startDate)->format('%a');
            $floored = floor($difference / $sprintLength);
            $currentSprint = $floored > $project->sprints ? $project->sprints : $floored;

            $newDate = $startDate->format('Y-m-d'); 
            
            $weeks = $currentSprint * 2;

            $sprintLength = $sprintLength - 1;
            $BeginDateCurrentSprint = date('Y-m-d', strtotime($newDate. " + $weeks weeks"));
            $endDateCurrentSprint = date('Y-m-d', strtotime($BeginDateCurrentSprint. " + $sprintLength days"));

            return [$BeginDateCurrentSprint, $endDateCurrentSprint];
        };

        $ScrumDashboardProject = Project::where('name', 'Scrum Dashboard')->first();
        $currentSprintDate = $project($ScrumDashboardProject);

        $dates = $getDatesFromRange($currentSprintDate[0], $currentSprintDate[1]);

        $length = 0;

        for($i = 0; $i < count($dates); $i++)
        { 
            $count = 0;
            for($j = 0; $j < count(array_keys($getDatesAndValues)); $j++)
            {
                $dates[$i] == array_keys($getDatesAndValues)[$j] ? $count = $sumDatesAndValues[$length] : 0;
                $dates[$i] == array_keys($getDatesAndValues)[$j] ? $length++ : 0;
            }

            array_push($completedTasks, $count);
            array_push($remainingTasks, $arraysum);
            $arraysum = $arraysum - $completedTasks[$i];    
        }
        

        // Burn down chart data
        $chart_data = [
            [
                'name' => 'Completed tasks',
                'type' => 'column',
                'data' => $completedTasks
            ],
            [
                'name' => 'Ideal burndown',
                'type' => 'area',
                'data' => $idealBurndownLine(array_sum($allTickets))
            ],
            [
                'name' => 'Tasks remaining',
                'type' => 'line',
                'data' => $remainingTasks
            ]
        ];

        // Return dataset
        return [
            'tickets_active' => array_sum($ticketsActive),
            'tickets_open' => array_sum($ticketsOpen),
            'tickets_complete' => array_sum($ticketsDone),
            'team_size' => count(array_unique($teamMembers, SORT_REGULAR)),
            'chart' => new BurndownChartResource($chart_data),
            'dates' => new DateResource($dates)
        ];
    }
}
