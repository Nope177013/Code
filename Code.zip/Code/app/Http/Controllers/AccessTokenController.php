<?php

namespace App\Http\Controllers;

use App\Http\Resources\ApiAuthResource;
use App\Http\Resources\UserResource;
use App\Models\User;
use Psr\Http\Message\ServerRequestInterface;

class AccessTokenController extends \Laravel\Passport\Http\Controllers\AccessTokenController
{
    public function issueToken(ServerRequestInterface $request)
    {
        $tokenResponse = parent::issueToken($request);
        $token = $tokenResponse->getContent();

        $token_info = json_decode($token, true);

        $username = $request->getParsedBody()['username'];
        $user = User::whereEmail($username)->first();
        $token_info = collect($token_info);
        $token_info->put('user', $user);

        return new ApiAuthResource($token_info);
    }
}
