<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Class ApiAuthentication
 * @package App\Http\Middleware
 */
class ApiAuthentication
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Retrieve client secret
        $client = DB::table('oauth_clients')->select('id', 'secret')
                                                  ->where('name', 'Laravel Password Grant Client')
                                                  ->first();

        // Pass the retrieved credentials into the request
        $request->merge([
            'grant_type'    => 'password',
            'client_id'     => $client->id,
            'client_secret' => $client->secret
        ]);

        return $next($request);
    }
}
