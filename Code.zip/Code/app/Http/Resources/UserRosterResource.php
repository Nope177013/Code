<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UserRosterResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'project'       => $this->project_name,
            'total_sprints' => $this->project_sprints,

            'sprint'     => $this->sprint,

            'calendar'      => [
                'mondays'    => $this->mondays,
                'tuesdays'   => $this->tuesdays,
                'wednesdays' => $this->wednesdays,
                'thursdays'  => $this->thursdays,
                'fridays'    => $this->fridays,
                'saturdays'  => $this->saturdays,
                'sundays'    => $this->sundays,
            ]
        ];
    }
}
